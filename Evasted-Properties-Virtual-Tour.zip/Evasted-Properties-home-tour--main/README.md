# Evasted Properties – Home Tour

A responsive property website with a photo gallery and a guided, button-controlled photo tour.

## Run locally
Open `index.html` in a web browser. Keep `styles.css`, `script.js`, and the `images` folder alongside it.

## Publish with GitHub Pages
Upload the contents of this folder to the root of the repository. In GitHub, open Settings → Pages, choose Deploy from a branch, select `main` and `/ (root)`, then Save.

## Guided tour
The Virtual tour section lets visitors move through the supplied exterior, living room, kitchen, bedroom, and bathroom photos using Previous and Next. This is a photo tour, not a 360-degree walkthrough.

## Important listing note
The supplied photos and property address have not been independently verified as belonging to the same property. Confirm the photos, ownership, availability, and listing details before publishing them as a verified listing.
